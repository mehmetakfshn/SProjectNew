#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Public/HexTileData.h" 
#include "PathfindingComponent.generated.h"

// A* algoritmas� i�in kullan�lan ge�ici bir d���m yap�s�
struct FPathNode
{
	FIntPoint Coordinates; // Bu d���m�n koordinat�
	int32 GCost; // Ba�lang��tan buraya gelmenin maliyeti
	int32 HCost; // Buradan hedefe tahmini maliyet (Heuristic)
	FPathNode* Parent; // Yolu yeniden olu�turmak i�in

	int32 FCost() const { return GCost + HCost; }

	FPathNode(FIntPoint Coords = FIntPoint(-1, -1), FPathNode* InParent = nullptr, int32 InGCost = 0, int32 InHCost = 0)
		: Coordinates(Coords), GCost(InGCost), HCost(InHCost), Parent(InParent) {
	}

	// E�itlik operat�r� (TArray::Contains i�in gerekli)
	bool operator==(const FPathNode& Other) const
	{
		return Coordinates == Other.Coordinates;
	}
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class SPROJECTNEW_API UPathfindingComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UPathfindingComponent();

	/**
	 * A* algoritmas�n� �al��t�ran ana fonksiyon.
	 * Blueprint'ten gelen Dizi'yi (TArray) al�r.
	 */
	UFUNCTION(BlueprintCallable, Category = "Pathfinding")
	bool FindPath(
		const TArray<FHexTileData>& GridDataArray,
		FIntPoint Start,
		FIntPoint End,
		TArray<FIntPoint>& OutPath
	);

	// --- HAR�TA MATEMAT�K ARA�LARI (Blueprint'te Kullan�lacak) ---
	// Bu fonksiyonlar, o sinir bozucu bo�luk sorununu ��zer.

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Pathfinding|Conversion")
	FIntPoint WorldToGrid(const FVector& WorldLocation, float TileSize) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Pathfinding|Conversion")
	FVector GridToWorld(FIntPoint GridCoord, float TileSize) const;


	FIntPoint WorldToGrid_Custom(const FVector& LocalPos, float TileSize) const;


private:
	/** �ki koordinat aras�ndaki tahmini mesafeyi (H Cost) hesaplar (Hex mesafesi) */
	int32 CalculateHeuristic(FIntPoint A, FIntPoint B);

	/** Bir karonun kom�ular�n� (6 y�n) d�nd�r�r */
	TArray<FIntPoint> GetNeighbors(FIntPoint Coords);

	/** Bulunan yolu (Parent'lardan geriye do�ru) yeniden olu�turur */
	TArray<FIntPoint> ReconstructPath(FPathNode* EndNode);

	/** A* �al��madan �nce Dizi'yi h�zl� arama i�in TMap'e d�n��t�r�r */
	TMap<FIntPoint, FHexTileData> ConvertArrayToMap(const TArray<FHexTileData>& GridDataArray);
};