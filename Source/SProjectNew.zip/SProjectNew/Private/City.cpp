#include "Public/City.h"

ACity::ACity()
{
    PrimaryActorTick.bCanEverTick = false;
}
