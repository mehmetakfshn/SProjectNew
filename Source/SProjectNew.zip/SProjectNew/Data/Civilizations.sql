INSERT INTO Civilizations (Name, Leader, ColorPrimary, ColorSecondary, StartingTech)
VALUES ('Republic of Turkey', 'Mustafa Kemal Ataturk', '#7d0000ff', '#ffffff', 'Sailing');


INSERT INTO Civilizations (Name, Leader, ColorPrimary, ColorSecondary, StartingTech)
VALUES ('United States of America', 'George Washington', '#00247d', '#ffffff', 'Sailing');


INSERT INTO Civilizations (Name, Leader, ColorPrimary, ColorSecondary, StartingTech)
VALUES ('United Kingdom', 'Charles III', '#00247d', '#ff0762ff', 'Sailing');


INSERT INTO Civilizations (Name, Leader, ColorPrimary, ColorSecondary, StartingTech)
VALUES ('Syrian Arab Republic', 'Ahmed al-Sharaa', '#007d02ff', '#ff0000ff', 'Sailing');


INSERT INTO Civilizations (Name, Leader, ColorPrimary, ColorSecondary, StartingTech)
VALUES ('Republic of Iraq', 'Saddam Hussein', '#000000ff', '#ff0000ff', 'Sailing');