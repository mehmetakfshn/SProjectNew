#include "UnitBase.h"
#include "Components/StaticMeshComponent.h"
#include "PathfindingComponent.h" // Yeni C++ bile�enimiz
#include "DrawDebugHelpers.h" // Yolu �izmek i�in

AUnitBase::AUnitBase()
{
	// Art�k her karede (Tick) �al��mas� gerekiyor
	PrimaryActorTick.bCanEverTick = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	UnitMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("UnitMesh"));
	UnitMesh->SetupAttachment(RootComponent);

	// T�klanabilir oldu�undan emin ol (daha �nce BP'de yapm��t�k)
	UnitMesh->SetCollisionResponseToChannel(ECC_Visibility, ECR_Block);

	// Varsay�lan de�erler
	CurrentGridCoords = FIntPoint(0, 0); // Ba�lang�� koordinat� (BP'den ezilmeli)
	MovementSpeed = 5.0f; // Ak�c� hareket h�z�

	MaxMovementPoints = 2;
	CurrentMovementPoints = MaxMovementPoints;

	bIsMoving = false;
	CurrentPathIndex = 0;
}

void AUnitBase::BeginPlay()
{
	Super::BeginPlay();
	CurrentMovementPoints = MaxMovementPoints;
}

// --- Ak�c� Hareket Mant��� (Tick) ---
void AUnitBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// E�er bIsMoving true ise ve takip edilecek bir yol varsa
	if (bIsMoving && WorldPathToFollow.IsValidIndex(CurrentPathIndex))
	{
		FVector CurrentLocation = GetActorLocation();
		FVector TargetLocation = WorldPathToFollow[CurrentPathIndex];

		if (FVector::DistSquared(CurrentLocation, TargetLocation) < FMath::Square(10.0f)) // 10 birim yak�ndaysak
		{
			// Bir sonraki noktaya ge�
			CurrentPathIndex++;
			if (!WorldPathToFollow.IsValidIndex(CurrentPathIndex))
			{
				// Yol bitti
				bIsMoving = false;
				SetActorLocation(TargetLocation); // Tam hedefe yerle�
				// Yolu �izmeyi b�rak
				FlushPersistentDebugLines(GetWorld());
			}
		}
		else
		{
			// Hedefe do�ru ak�c� hareket et (Interp)
			FVector NewLocation = FMath::VInterpTo(
				CurrentLocation,
				TargetLocation,
				DeltaTime,
				MovementSpeed
			);
			SetActorLocation(NewLocation);
		}
	}
}

// --- Yeni Hareket Fonksiyonu ---
void AUnitBase::MoveAlongPath(
	const TArray<FIntPoint>& PathCoordinates,
	UPathfindingComponent* PathfindingComponent,
	float TileSize
)
{
	if (bIsMoving) return; // Zaten hareket ediyorsa yenisini ba�latma

	WorldPathToFollow.Empty();

	// Koordinat yolunu (FIntPoint) D�nya Konumu yoluna (FVector) �evir
	for (const FIntPoint& Coords : PathCoordinates)
	{
		FVector WorldPos = PathfindingComponent->GridToWorld(Coords, TileSize);
		// Birimin havada durmas� i�in Z ofsetini ekle
		WorldPos.Z += 2.0f;
		WorldPathToFollow.Add(WorldPos);
	}

	// Yolu �izmeyi ba�lat
	DrawPath();

	// Hareketi ba�lat
	CurrentPathIndex = 1; // 0. indeks zaten oldu�umuz yerdir, 1'den ba�la
	bIsMoving = true;
}

// --- Yolu �izme Fonksiyonu ---
void AUnitBase::DrawPath()
{
	// �nceki �izgileri temizle
	FlushPersistentDebugLines(GetWorld());

	if (WorldPathToFollow.Num() < 2) return;

	// Yol boyunca �izgiler �iz
	for (int32 i = 0; i < WorldPathToFollow.Num() - 1; i++)
	{
		DrawDebugLine(
			GetWorld(),
			WorldPathToFollow[i], // Ba�lang��
			WorldPathToFollow[i + 1], // Biti�
			FColor::Yellow,
			true, // Kal�c� (hareket bitene kadar)
			-1.0f,
			0,
			5.0f // �izgi kal�nl���
		);
	}
}

// --- �statistik Fonksiyonlar� (De�i�iklik Yok) ---
bool AUnitBase::CanMove() const
{
	return CurrentMovementPoints > 0;
}
void AUnitBase::SpendMovement(int32 Cost)
{
	CurrentMovementPoints = FMath::Max(0, CurrentMovementPoints - Cost);
}
void AUnitBase::ResetForNewTurn()
{
	CurrentMovementPoints = MaxMovementPoints;
	UE_LOG(LogTemp, Warning, TEXT("%s adli birimin hareket puanlari yenilendi."), *GetName());
}

void AUnitBase::InitUnit(UCivilizationManager* OwnerCiv, const FUnitData& Data, const FIntPoint& GridPos)
{
	OwnerCivilization = OwnerCiv;     // E�er b�yle bir de�i�ken yoksa ekleriz
	UnitData = Data;                  // E�er b�yle bir de�i�ken yoksa ekleriz
	GridPosition = GridPos;           // E�er b�yle bir de�i�ken yoksa ekleriz

	UE_LOG(LogTemp, Warning, TEXT("Unit initialized: %s at %d,%d"),
		*Data.DisplayName, GridPos.X, GridPos.Y);
}
