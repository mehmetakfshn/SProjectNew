// Copyright Epic Games, Inc. All Rights Reserved.


#include "TwinStickNPCDestruction.h"

ATwinStickNPCDestruction::ATwinStickNPCDestruction()
{
 	PrimaryActorTick.bCanEverTick = true;

}