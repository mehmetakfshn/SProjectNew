#include "MainMenuGameMode.h"

AMainMenuGameMode::AMainMenuGameMode()
{
    // Men�n�n �zel bir davran��� yok, sade GameMode
}

