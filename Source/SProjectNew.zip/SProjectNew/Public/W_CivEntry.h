#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Database/DatabaseReader.h"   // FCivInfo i�in
#include "W_CivEntry.generated.h"

// Zaten mevcut olmas� muhtemel, ama yoksa ekle:
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FCivSelectedSignature, const FCivInfo&, Info);

// YEN�: AI se�imi de�i�ti�inde kullan�lacak delegate
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FCivAISelectionChangedSignature, const FCivInfo&, Info, bool, bIsSelected);

UCLASS()
class SPROJECTNEW_API UW_CivEntry : public UUserWidget
{
    GENERATED_BODY()

public:

    // Entry'deki Civ bilgisini tutar
    UPROPERTY(BlueprintReadOnly)
    FCivInfo CivInfo;

    // Oyuncu kendi civini se�ti�inde tetiklenir
    UPROPERTY(BlueprintAssignable, Category = "Civ")
    FCivSelectedSignature OnCivSelected;

    // Bu civ AI listesine eklenip/��kar�ld���nda tetiklenir
    UPROPERTY(BlueprintAssignable, Category = "Civ")
    FCivAISelectionChangedSignature OnAISelectionChanged;

    // C++ taraf�ndan CivInfo atamak i�in kullan�lan fonksiyon
    UFUNCTION(BlueprintCallable)
    void SetCiv(const FCivInfo& Info);

protected:

    virtual void NativeConstruct() override;

    // Blueprint ile bind edilecek UI elemanlar�
    UPROPERTY(meta = (BindWidget))
    class UButton* Button_Select;

    UPROPERTY(meta = (BindWidget))
    class UTextBlock* Text_CivName;

    // YEN�: Bu sat�r� AI i�in i�aretlemek amac�yla kullanaca��z
    UPROPERTY(meta = (BindWidgetOptional))
    class UCheckBox* CheckBox_IsAI;

    // �� t�klama fonksiyonu (Select butonu)
    UFUNCTION()
    void HandleClick();

    // YEN�: Checkbox de�i�ince �a�r�lacak fonksiyon
    UFUNCTION()
    void HandleAICheckChanged(bool bIsChecked);
};
