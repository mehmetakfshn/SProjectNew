// CivilizationData.h

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Database/DatabaseReader.h"   // FCivInfo burada tan�ml�ysa
#include "CivilizationData.generated.h"

UCLASS(BlueprintType)
class SPROJECTNEW_API UCivilizationData : public UObject
{
    GENERATED_BODY()

public:

    // SQL'den gelen ham civ bilgisi
    UPROPERTY(BlueprintReadOnly)
    FCivInfo BaseInfo;

    // Ana ve ikincil renk (UI i�in)
    UPROPERTY(BlueprintReadOnly)
    FLinearColor CivColor;

    UPROPERTY(BlueprintReadOnly)
    FLinearColor CivSecondaryColor;

    // �leride dolduraca��m�z alanlar (�imdilik bo� kals�n)
    UPROPERTY(BlueprintReadOnly)
    FString CapitalName;

    UPROPERTY(BlueprintReadOnly)
    TArray<FString> CityNames;

    // Bu civin �retebilece�i unit t�rleri (CivUnits tablosundan)
    UPROPERTY(BlueprintReadOnly)
    TArray<FString> AllowedUnitTypes;

};
