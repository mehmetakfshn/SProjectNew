#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Database/DatabaseReader.h"
#include "W_SelectCiv.generated.h"

class UW_CivEntry;
class UScrollBox;
class UButton;

UCLASS()
class SPROJECTNEW_API UW_SelectCiv : public UUserWidget
{
    GENERATED_BODY()

public:

    // Se�ilen oyuncu civ'i
    UPROPERTY(BlueprintReadOnly)
    FCivInfo SelectedCiv;

    // Se�ilen AI civ listesi (checkbox'tan gelir)
    UPROPERTY(BlueprintReadOnly)
    TArray<FCivInfo> SelectedAICivs;

protected:

    virtual void NativeConstruct() override;

    // Civ entry i�in widget class (zaten b�y�k ihtimalle var)
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Civ")
    TSubclassOf<class UW_CivEntry> CivEntryClass;

    // Civ listesinin dolduruldu�u ScrollBox (zaten muhtemelen var)
    UPROPERTY(meta = (BindWidget))
    class UScrollBox* ScrollBox_Civs;

    // Start Game butonu
    UPROPERTY(meta = (BindWidget))
    class UButton* Button_StartGame;

private:

    // Listeyi doldurur
    void PopulateCivList();

    // Bir entry t�klan�nca (player civ se�imi)
    UFUNCTION()
    void OnCivSelected(const FCivInfo& Info);

    // YEN�: Entry'deki AI checkbox de�i�ince
    UFUNCTION()
    void OnAICivSelectionChanged(const FCivInfo& Info, bool bIsSelected);

    // StartGame butonuna bas�l�rsa
    UFUNCTION()
    void HandleStartGameClicked();
};

