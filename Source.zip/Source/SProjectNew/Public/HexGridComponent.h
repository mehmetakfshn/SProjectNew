#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HexTileData.h"
#include "HexEnums.h"


class UTexture2D;

#include "HexGridComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class SPROJECTNEW_API UHexGridComponent : public UActorComponent
{
    GENERATED_BODY()

public:

    UHexGridComponent();

    // ==============================
    // GRID PARAMETERS
    // ==============================

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Hex Grid")
    int32 GridWidth = 80;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Hex Grid")
    int32 GridHeight = 80;

    // ==============================
    // EARTH HEIGHTMAP SETTINGS
    // ==============================

    // Bu a��kken GenerateGrid, normal rastgele/flat grid yerine Earth heightmap'inden �retir.
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Earth")
    bool bUseEarthHeightmap = false;

    // Equirectangular Earth heightmap (grayscale, R kanal� y�kseklik gibi d���n�lebilir)
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Earth", meta = (EditCondition = "bUseEarthHeightmap"))
    UTexture2D* EarthHeightmapTexture = nullptr;

    // 0�1 aras�: bunun alt� deniz
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Earth", meta = (EditCondition = "bUseEarthHeightmap", ClampMin = "0.0", ClampMax = "1.0"))
    float SeaLevelThreshold = 0.40f;

    // 0�1 aras�: bunun �st� da�
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Earth", meta = (EditCondition = "bUseEarthHeightmap", ClampMin = "0.0", ClampMax = "1.0"))
    float MountainThreshold = 0.75f;

    // Ekvatora yak�n enlemler ��l olsun diye kullan�lan e�ik (derece)
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Earth", meta = (EditCondition = "bUseEarthHeightmap", ClampMin = "0.0", ClampMax = "90.0"))
    float DesertLatitude = 25.0f;


    // ==============================
    // GRID DATA STORAGE
    // ==============================

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Hex Grid")
    TArray<FHexTileData> GridData;


    // ==============================
    // GRID GENERATION
    // ==============================

    /** GridData dizisini doldurur */
    UFUNCTION(BlueprintCallable, Category = "Hex Grid")
    void GenerateGrid();


    // ==============================
    // COORDINATE CONVERSION
    // ==============================

    /** Axial grid koordinat�n� d�nyadaki noktaya �evirir */
    UFUNCTION(BlueprintCallable, Category = "Hex Grid")
    FVector GridToWorld(int32 X, int32 Y) const;

    /** D�nya koordinat�ndan grid koordinat�na �evirir */
    UFUNCTION(BlueprintCallable, Category = "Hex Grid")
    FIntPoint WorldToGrid(const FVector& WorldLocation) const;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float TileScale = 1.0f;

    // Grid'i her seferinde heightmap'ten �retmek yerine
    // bir kez SQL'e kaydedip sonra hep ordan okuyal�m.
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Earth|Database")
    bool bUseDatabaseCache = true;

    // �leride farkl� map'ler olursa ay�rmak i�in kullanabiliriz.
    // �imdilik tek Earth haritas� oldu�undan sadece bilgi ama�l�.
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Earth|Database")
    FString MapName = TEXT("Earth_120x96");

    // Mesh'in ger�ek �l��leri (asla de�i�mez)
    static constexpr float BaseTileWidth = 173.f;
    static constexpr float BaseTileHeight = 200.f;

    // �l�eklenmi� de�erler
    float TileWidth;
    float TileHeight;

    void DetectLakesAndOceans();

    TArray<int32> FindRiverSources() const;
    void GenerateRiverFromSource(int32 StartIndex);
    void GenerateAllRivers();
    

    UPROPERTY(EditAnywhere, Category = "Terrain")
    UTexture2D* HeightmapTexture;

    /** 120x96 sabit edit�r grid'i olu�turur (t�m� Grass, height=0). */
    UFUNCTION(BlueprintCallable, Category = "Hex Grid|Editor")
    void InitializeEditorGrid();

    /** Grid s�n�rlar� i�inde mi? */
    UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Hex Grid|Editor")
    bool IsValidCoords(int32 X, int32 Y) const;

    /** Tek bir tile datas�n� kopya olarak d�ner. */
    UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Hex Grid|Editor")
    FHexTileData GetTileData(int32 X, int32 Y) const;

    /** Sadece tile t�r�n� de�i�tirir (Grass, Desert, Water vs.). */
    UFUNCTION(BlueprintCallable, Category = "Hex Grid|Editor")
    void SetTileTypeAt(int32 X, int32 Y, ETileType NewType);

    /** Y�kseklik seviyesini do�rudan ayarlar. */
    UFUNCTION(BlueprintCallable, Category = "Hex Grid|Editor")
    void SetTileHeightLevel(int32 X, int32 Y, int32 NewHeightLevel);

    /** HeightLevel'i delta kadar art�r�r/azalt�r. */
    UFUNCTION(BlueprintCallable, Category = "Hex Grid|Editor")
    void AddTileHeightLevel(int32 X, int32 Y, int32 DeltaLevels);

    /** Belirli bir kenarda nehir var/yok ayarlama. */
    UFUNCTION(BlueprintCallable, Category = "Hex Grid|Editor")
    void SetRiverAtEdge(int32 X, int32 Y, ERiverEdge Edge, bool bHasRiver);

    /** HexGridActor �zerinden g�rsel rebuild talebi. */
    UFUNCTION(BlueprintCallable, Category = "Hex Grid|Editor")
    void RequestRebuildVisual();

    bool SaveGridToDatabase() const;

    bool SaveGridToDatabaseWithName(const FString& InMapName) const;

    bool LoadGridFromDatabaseWithName(const FString& MapName);



    #if WITH_EDITOR
        virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
    #endif






protected:

    virtual void BeginPlay() override;


private:

    // Earth heightmap'ten grid �retir
    void GenerateGridFromEarthHeightmap();

    // Y�kseklik + enlem bilgisine g�re tile tipi se�er
    ETileType ChooseTileTypeFromHeightAndLat(float Height01, int32 GridY) const;

    bool LoadGridFromDatabase();

    /** Bir hex tile merkezinin world offset'ini hesaplar */
    FVector GetHexOffset(int32 X, int32 Y) const;

    TArray<FIntPoint> GetNeighbors(int32 X, int32 Y) const;

    


};
