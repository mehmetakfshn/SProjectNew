#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "Database/DatabaseReader.h"       // FCivInfo struct i�in
#include "CivGameInstance.generated.h"

UCLASS()
class SPROJECTNEW_API UCivGameInstance : public UGameInstance
{
    GENERATED_BODY()

public:

    // Kullan�c�n�n se�ti�i Civilization bilgisi
    UPROPERTY(BlueprintReadWrite, VisibleAnywhere)
    FCivInfo SelectedCiv;

    // Se�ilen AI Civilization'lar
    UPROPERTY(BlueprintReadWrite, VisibleAnywhere)
    TArray<FCivInfo> SelectedAICivs;

    // Kolayl�k olsun diye AI say�s�n� da tutal�m (SelectedAICivs.Num() ile uyumlu olacak)
    UPROPERTY(BlueprintReadWrite, VisibleAnywhere)
    int32 NumAICivs = 0;
};
