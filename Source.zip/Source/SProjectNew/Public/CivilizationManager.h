#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Public/CivilizationData.h"
#include "CivilizationManager.generated.h"

UCLASS()
class SPROJECTNEW_API UCivilizationManager : public UObject
{
    GENERATED_BODY()

public:

    UFUNCTION(BlueprintCallable)
    UCivilizationData* GetCivilizationData() const { return CivData; }

    UFUNCTION(BlueprintCallable)
    bool CanProduceUnit(const FString& UnitType) const
    {
        return CivData && CivData->AllowedUnitTypes.Contains(UnitType);
    }


    void Init(const FCivInfo& SelectedCivInfo);

protected:
    UPROPERTY()
    UCivilizationData* CivData;

};
