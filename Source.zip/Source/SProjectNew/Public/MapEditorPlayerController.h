#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "HexTileData.h"
#include "HexEnums.h"
#include "MapEditorPlayerController.generated.h"

UCLASS()
class SPROJECTNEW_API AMapEditorPlayerController : public APlayerController
{
    GENERATED_BODY()

public:
    AMapEditorPlayerController();

    virtual void SetupInputComponent() override;

    // UMG'den �a�r�lacak: aktif tile tipi
    UFUNCTION(BlueprintCallable, Category = "Map Editor")
    void SetCurrentTileType(ETileType NewType);

    // UMG'den �a�r�lacak: y�kseklik delta (+1 / -1)
    UFUNCTION(BlueprintCallable, Category = "Map Editor")
    void SetCurrentHeightDelta(int32 NewDelta);

    // UMG'den �a�r�lacak: nehir �izme modu
    UFUNCTION(BlueprintCallable, Category = "Map Editor")
    void SetRiverDrawMode(bool bEnable);


    UFUNCTION(BlueprintCallable)
    void SaveMapWithName(const FString& MapName);

    UFUNCTION(BlueprintCallable, Category = "Map Editor")
    TArray<FString> GetSavedMapList() const;

    UFUNCTION(BlueprintCallable, Category = "Map Editor")
    void LoadMap(const FString& MapName);




protected:
    void OnLeftMouseClick();   // Tile tipi boyama / nehir
    void OnRightMouseClick();  // Y�kseklik de�i�tirme

private:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Editor", meta = (AllowPrivateAccess = "true"))
    ETileType CurrentPaintTileType;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Editor", meta = (AllowPrivateAccess = "true"))
    int32 CurrentHeightDelta;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Editor", meta = (AllowPrivateAccess = "true"))
    bool bRiverMode;
};
