#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Database/DatabaseReader.h"
#include "CivilizationData.generated.h"

UCLASS()
class SPROJECTNEW_API UCivilizationData : public UObject
{
    GENERATED_BODY()

public:

    FCivInfo BaseInfo;      // SQL�den gelen temel bilgiler
    FLinearColor CivColor;  // Ana renk
    FLinearColor CivSecondaryColor; // �kinci renk
    FString StartBias;      // Desert / Forest / Grass / Tundra / Hill

    FString CapitalName;    // Ba�kent (istersen)
    TArray<FString> CityNames; // �ehir listesi

    UPROPERTY(BlueprintReadOnly)
    TArray<FString> AllowedUnitTypes;
};
