#include "CivGameMode.h"
#include "CivGameState.h"
#include "CivGameInstance.h"
#include "CivPlayerController.h" // Kendi PlayerController'�m�z� dahil ediyoruz
#include "UnitBase.h"
#include "Kismet/GameplayStatics.h"
#include "UnitBase.h" // YEN�: UnitBasei tan�mak i�in
#include "Kismet/GameplayStatics.h" // YEN�: GetActorOfClass i�in
#include "CivSaveGame.h"
#include "PathfindingComponent.h"
#include "HexGridComponent.h"
#include "sqlite3.h"
#include "Database/DatabaseInitializer.h"
#include "Database/DatabaseReader.h"  
#include "Public/Managers/UnitManager.h"
#include "Public/UnitData.h"






ACivGameMode::ACivGameMode()
{
	GameStateClass = ACivGameState::StaticClass();
	PlayerControllerClass = ACivPlayerController::StaticClass();
    DefaultUnitClass = AUnitBase::StaticClass();

}


void ACivGameMode::BeginPlay()
{
    Super::BeginPlay();

    UCivGameInstance* GI = Cast<UCivGameInstance>(GetGameInstance());
    if (!GI)
    {
        UE_LOG(LogTemp, Error, TEXT("CivGameInstance cast FAILED in GameMode!"));
        return;
    }

    // ======================================================
    // PLAYER CIV
    // ======================================================
    ActiveCiv = GI->SelectedCiv;

    UE_LOG(LogTemp, Warning, TEXT("[C++] Player Civ: %s (Leader: %s)"),
        *ActiveCiv.Name,
        *ActiveCiv.Leader
    );

    // Player Civ i�in CivilizationManager olu�tur
    PlayerCivManager = NewObject<UCivilizationManager>(this);
    PlayerCivManager->Init(ActiveCiv);

    // ======================================================
    // AI CIV LISTESI
    // ======================================================
    AICivs = GI->SelectedAICivs;

    for (int32 i = 0; i < AICivs.Num(); i++)
    {
        UE_LOG(LogTemp, Warning, TEXT("[C++] AI Civ[%d]: %s (Leader: %s)"),
            i,
            *AICivs[i].Name,
            *AICivs[i].Leader
        );

        // Her AI i�in CivilizationManager olu�tur
        UCivilizationManager* NewAI = NewObject<UCivilizationManager>(this);
        NewAI->Init(AICivs[i]);
        AICivManagers.Add(NewAI);
    }

    // ======================================================
    // DATABASE + UNIT SYSTEM (�NCEK� KODUN AYNISI)
    // ======================================================
    if (HasAuthority())
    {
        // 1) Ana veritaban� init
        UDatabaseInitializer::InitializeDatabase();

        // 2) T�m civ'leri oku
        TArray<FCivInfo> Civs = UDatabaseReader::GetAllCivilizations();

        for (const FCivInfo& Civ : Civs)
        {
            UE_LOG(LogTemp, Warning, TEXT("Civ SQL Loaded: %s - Leader: %s"),
                *Civ.Name,
                *Civ.Leader
            );
        }

        // 3) DBReader olu�tur
        DBReader = NewObject<UDatabaseReader>();

        // 4) Veritaban�n� a�
        FString DBPath = FPaths::ProjectContentDir() / TEXT("Data/GameData.db");
        if (!DBReader->OpenDatabase(DBPath))
        {
            UE_LOG(LogTemp, Error, TEXT("FAILED TO OPEN DB at %s"), *DBPath);
            return;
        }

        UE_LOG(LogTemp, Warning, TEXT("DB OPENED SUCCESSFULLY at %s"), *DBPath);

        // 5) UnitManager y�kle
        UnitManager = NewObject<UUnitManager>();
        UnitManager->Init(DBReader);

        // Test birimi
        FUnitData TestData;
        if (UnitManager->GetUnitData("UNIT_T90S", TestData))
        {
            UE_LOG(LogTemp, Warning,
                TEXT("Unit SQL Loaded: %s (Movement=%d, Cost=%d)"),
                *TestData.DisplayName,
                TestData.Movement,
                TestData.Cost
            );
        }
        else
        {
            UE_LOG(LogTemp, Error,
                TEXT("UNIT_T90S NOT FOUND IN Units.sql !!!"));
        }
    }
    {
        TArray<FString> PlayerUnits;
        DBReader->GetUnitsForCiv(ActiveCiv.Name, PlayerUnits);

        PlayerCivManager->GetCivilizationData()->AllowedUnitTypes = PlayerUnits;

        UE_LOG(LogTemp, Warning,
            TEXT("[C++] Player Allowed Units: %d"),
            PlayerUnits.Num());
    }

    // AI CIVS
    for (int32 i = 0; i < AICivs.Num(); i++)
    {
        TArray<FString> AIUnits;
        DBReader->GetUnitsForCiv(AICivs[i].Name, AIUnits);

        AICivManagers[i]->GetCivilizationData()->AllowedUnitTypes = AIUnits;

        UE_LOG(LogTemp, Warning,
            TEXT("[C++] AI Civ %s Allowed Units: %d"),
            *AICivs[i].Name,
            AIUnits.Num());
    }

    InitUnitFactory();
    if (UnitFactory && PlayerCivManager)
    {
        TArray<FString> Allowed = PlayerCivManager->GetCivilizationData()->AllowedUnitTypes;

        if (Allowed.Num() > 0)
        {
            // �lk izin verilen birim
            FString FirstUnit = Allowed[0];

            // Haritan�n ortas�na spawn edelim
            FIntPoint TestTile(10, 10);

            UnitFactory->CreateUnit(PlayerCivManager, FirstUnit, TestTile);
        }
        else
        {
            UE_LOG(LogTemp, Error, TEXT("[TEST] Player civ i�in AllowedUnitTypes BO�!"));
        }
    }
}





void ACivGameMode::EndPlayerTurn()
{
	UE_LOG(LogTemp, Warning, TEXT("ACivGameMode: EndPlayerTurn() cagrildi."));

	// 1. GameState'e Ula� ve Turu �lerlet
	ACivGameState* const GS = GetGameState<ACivGameState>();
	if (!GS)
	{
		UE_LOG(LogTemp, Error, TEXT("EndPlayerTurn: CivGameState bulunamadi!"));
		return;
	}
	GS->AdvanceTurn(); // �rn: 1. Tur  2. Tur

	// 2. YEN� MANTIK: Sahnede AUnitBase tipindeki T�M akt�rleri bul
	TArray<AActor*> FoundUnits;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), AUnitBase::StaticClass(), FoundUnits);

	UE_LOG(LogTemp, Warning, TEXT("C++: Sahnede %d adet birim bulundu, puanlar yenileniyor..."), FoundUnits.Num());

	// 3. Bulunan her birimin puan�n� yenile
	for (AActor* UnitActor : FoundUnits)
	{
		AUnitBase* Unit = Cast<AUnitBase>(UnitActor);
		if (Unit)
		{
			Unit->ResetForNewTurn(); // Bizim C++ fonksiyonumuz
		}
	}
}

void ACivGameMode::SaveGameToSlot()
{
    UCivSaveGame* SaveGameInstance = Cast<UCivSaveGame>(
        UGameplayStatics::CreateSaveGameObject(UCivSaveGame::StaticClass())
    );

    if (!SaveGameInstance)
    {
        UE_LOG(LogTemp, Error, TEXT("SaveGameToSlot: SaveGameInstance olusturulamadi!"));
        return;
    }

    // 1) TURN
    ACivGameState* GS = GetGameState<ACivGameState>();
    if (GS)
    {
        SaveGameInstance->SavedTurnNumber = GS->GetCurrentTurn();
    }

    // 2) GRID DATA � BP_GridLogicNew �zerindeki GridData al�n�r
    AActor* GridActor = UGameplayStatics::GetActorOfClass(GetWorld(),
        StaticLoadClass(UObject::StaticClass(), nullptr, TEXT("/Game/BP_GridLogicNew.BP_GridLogicNew_C"))
    );

    if (GridActor)
    {
        FProperty* Property = GridActor->GetClass()->FindPropertyByName(TEXT("GridData"));
        FArrayProperty* ArrayProp = CastField<FArrayProperty>(Property);

        if (ArrayProp)
        {
            FScriptArrayHelper ArrayHelper(ArrayProp, ArrayProp->ContainerPtrToValuePtr<void>(GridActor));
            for (int32 i = 0; i < ArrayHelper.Num(); i++)
            {
                FHexTileData* TilePtr = reinterpret_cast<FHexTileData*>(ArrayHelper.GetRawPtr(i));
                SaveGameInstance->SavedGridData.Add(*TilePtr);
            }
        }
    }

    // 3) T�M B�R�MLER� KAYDET
    TArray<AActor*> FoundUnits;
    UGameplayStatics::GetAllActorsOfClass(GetWorld(), AUnitBase::StaticClass(), FoundUnits);

    for (AActor* Actor : FoundUnits)
    {
        AUnitBase* Unit = Cast<AUnitBase>(Actor);
        if (Unit)
        {
            FUnitSaveData Data;
            Data.WorldLocation = Unit->GetActorLocation();
            Data.GridCoords = Unit->CurrentGridCoords;
            Data.CurrentMovement = Unit->CurrentMovementPoints;
            Data.MaxMovement = Unit->MaxMovementPoints;

            // Class path ? spawn i�in gerekli
            Data.UnitClassPath = Unit->GetClass()->GetPathName();

            SaveGameInstance->SavedUnits.Add(Data);
        }
    }

    // 4) DOSYAYA YAZ
    if (UGameplayStatics::SaveGameToSlot(SaveGameInstance, TEXT("CivSaveSlot"), 0))
    {
        UE_LOG(LogTemp, Warning, TEXT("SAVE BASARILI."));
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("SAVE BASARISIZ!"));
    }
}

void ACivGameMode::LoadGameFromSlot()
{
    USaveGame* Loaded = UGameplayStatics::LoadGameFromSlot(TEXT("CivSaveSlot"), 0);
    UCivSaveGame* SaveGameInstance = Cast<UCivSaveGame>(Loaded);

    if (!SaveGameInstance)
    {
        UE_LOG(LogTemp, Error, TEXT("LOAD BASARISIZ! Save dosyasi yok."));
        return;
    }

    // 1) TURN'I Y�KLE
    ACivGameState* GS = GetGameState<ACivGameState>();
    if (GS)
    {
        GS->SetCurrentTurn(SaveGameInstance->SavedTurnNumber);
    }

    // 2) GRID'I Y�KLE
    AActor* GridActor = UGameplayStatics::GetActorOfClass(GetWorld(),
        StaticLoadClass(UObject::StaticClass(), nullptr, TEXT("/Game/BP_GridLogicNew.BP_GridLogicNew_C"))
    );

    if (GridActor)
    {
        FProperty* Property = GridActor->GetClass()->FindPropertyByName(TEXT("GridData"));
        FArrayProperty* ArrayProp = CastField<FArrayProperty>(Property);

        if (ArrayProp)
        {
            FScriptArrayHelper ArrayHelper(ArrayProp, ArrayProp->ContainerPtrToValuePtr<void>(GridActor));
            ArrayHelper.EmptyValues();

            for (const FHexTileData& Tile : SaveGameInstance->SavedGridData)
            {
                int32 NewIndex = ArrayHelper.AddValue();
                FHexTileData* TilePtr = reinterpret_cast<FHexTileData*>(ArrayHelper.GetRawPtr(NewIndex));
                *TilePtr = Tile;
            }
        }
    }

    // 3) SAHNEDEK� T�M B�R�MLER� S�L
    {
        TArray<AActor*> FoundUnits;
        UGameplayStatics::GetAllActorsOfClass(GetWorld(), AUnitBase::StaticClass(), FoundUnits);

        for (AActor* Actor : FoundUnits)
        {
            Actor->Destroy();
        }
    }

    // 4) KAYITLI B�R�MLER� YEN�DEN SPAWN ET
    for (const FUnitSaveData& SavedUnit : SaveGameInstance->SavedUnits)
    {
        UClass* UnitClass = LoadObject<UClass>(nullptr, *SavedUnit.UnitClassPath);
        if (!UnitClass) continue;

        FActorSpawnParameters Params;
        AUnitBase* NewUnit = GetWorld()->SpawnActor<AUnitBase>(
            UnitClass,
            SavedUnit.WorldLocation,
            FRotator::ZeroRotator,
            Params
        );

        if (NewUnit)
        {
            NewUnit->CurrentGridCoords = SavedUnit.GridCoords;
            NewUnit->MaxMovementPoints = SavedUnit.MaxMovement;
            NewUnit->CurrentMovementPoints = SavedUnit.CurrentMovement;
        }
    }

    UE_LOG(LogTemp, Warning, TEXT("LOAD TAMAMLANDI."));
}

AUnitBase* ACivGameMode::SpawnUnitAtTile(TSubclassOf<AUnitBase> UnitClass, FIntPoint GridCoords)
{
    if (!UnitClass) return nullptr;

    // Grid actor�n� bul (BP_HexGrid)
    UClass* GridClass = LoadClass<AActor>(nullptr, TEXT("/Game/BP_HexGrid.BP_HexGrid_C"));
    AActor* GridActor = UGameplayStatics::GetActorOfClass(GetWorld(), GridClass);

    if (!GridActor)
    {
        UE_LOG(LogTemp, Error, TEXT("SpawnUnitAtTile: BP_HexGrid bulunamad�!"));
        return nullptr;
    }

    // HexGridComponent'i al
    UHexGridComponent* HexComp = GridActor->FindComponentByClass<UHexGridComponent>();
    if (!HexComp)
    {
        UE_LOG(LogTemp, Error, TEXT("SpawnUnitAtTile: HexGridComponent bulunamad�!"));
        return nullptr;
    }

    // GridToWorld -> HexGridComponent local space kullan�r
    FVector WorldPos = HexComp->GridToWorld(GridCoords.X, GridCoords.Y);


    // Local -> World offset ekle
    WorldPos += GridActor->GetActorLocation();

    // Z offset (zeminde g�r�n�r olsun)
    WorldPos.Z += 50.f;

    // Spawn parameters
    FActorSpawnParameters Params;
    Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

    // Spawn actor
    AUnitBase* SpawnedUnit = GetWorld()->SpawnActor<AUnitBase>(UnitClass, WorldPos, FRotator::ZeroRotator, Params);

    if (SpawnedUnit)
    {
        SpawnedUnit->CurrentGridCoords = GridCoords;
        UE_LOG(LogTemp, Warning, TEXT("Unit spawn edildi. Koord: X=%d, Y=%d"), GridCoords.X, GridCoords.Y);
    }

    return SpawnedUnit;
}

void ACivGameMode::CreatePlayerCiv()
{
    PlayerCivManager = NewObject<UCivilizationManager>(this);
    PlayerCivManager->Init(ActivePlayerCiv);

    UE_LOG(LogTemp, Warning, TEXT("Created Player Civilization Manager for %s"), *ActivePlayerCiv.Name);
}

void ACivGameMode::CreateAICivs()
{
    for (int32 i = 0; i < AICivs.Num(); i++)
    {
        UCivilizationManager* NewAI = NewObject<UCivilizationManager>(this);
        NewAI->Init(AICivs[i]);

        AICivManagers.Add(NewAI);

        UE_LOG(LogTemp, Warning, TEXT("Created AI Civilization Manager for: %s"), *AICivs[i].Name);
    }
}

void ACivGameMode::InitUnitFactory()
{
    UnitFactory = NewObject<UUnitFactory>(this);
    UnitFactory->Init(this);

    UE_LOG(LogTemp, Warning, TEXT("UnitFactory initialized"));
}



