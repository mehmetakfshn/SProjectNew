#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "CivHUDWidget.generated.h"


class UButton;
class UTextBlock;

UCLASS()
class SPROJECTNEW_API UCivHUDWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	UPROPERTY(meta = (BindWidget))
	UButton* NextTurnButton;

	UPROPERTY(meta = (BindWidgetOptional))
	UTextBlock* TurnText;

	/** Widget olu�turuldu�unda �a�r�l�r (BeginPlay gibi) */
	virtual void NativeConstruct() override;

	/** NextTurnButton'a t�kland���nda bu fonksiyon �al���r */
	UFUNCTION()
	void OnNextTurnClicked();

public:
	// YEN�: UMG'de Text Bind ile kullanaca��m�z fonksiyon
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Turn System")
	FText GetTurnText() const;
};