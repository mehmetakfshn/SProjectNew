#include "UnitFactory.h"
#include "CivGameMode.h"
#include "CivilizationManager.h"
#include "Public/Managers/UnitManager.h"
#include "UnitBase.h"
#include "HexGridComponent.h"

void UUnitFactory::Init(ACivGameMode* InGameMode)
{
    GameMode = InGameMode;
}

AUnitBase* UUnitFactory::CreateUnit(
    UCivilizationManager* OwnerCiv,
    const FString& UnitType,
    const FIntPoint& GridPos)
{
    if (!GameMode || !GameMode->UnitManager)
    {
        UE_LOG(LogTemp, Error, TEXT("[UnitFactory] GameMode or UnitManager NULL!"));
        return nullptr;
    }

    // 1) Unit verisini SQL�den �ek
    FUnitData Data;
    if (!GameMode->UnitManager->GetUnitData(UnitType, Data))
    {
        UE_LOG(LogTemp, Error, TEXT("[UnitFactory] UnitType NOT FOUND: %s"), *UnitType);
        return nullptr;
    }

    // 2) World kordinat� hesapla
    FVector SpawnLocation(GridPos.X * 200.f, GridPos.Y * 200.f, 0.f);

    // 3) D�nyaya bir unit spawn et
    AUnitBase* NewUnit = GameMode->GetWorld()->SpawnActor<AUnitBase>(
        GameMode->UnitBlueprintClass,  // ileride Blueprint assign edilecek
        SpawnLocation,
        FRotator::ZeroRotator
    );

    if (!NewUnit)
        return nullptr;

    // 4) Unit�e civ verisi
    NewUnit->InitUnit(OwnerCiv, Data, GridPos);

    UE_LOG(LogTemp, Warning, TEXT("[UnitFactory] Spawned %s for %s at %d,%d"),
        *UnitType,
        *OwnerCiv->GetCivilizationData()->BaseInfo.Name,
        GridPos.X, GridPos.Y);

    return NewUnit;
}
