#include "Public/CivilizationManager.h"

void UCivilizationManager::Init(const FCivInfo& SelectedCiv)
{
    // CivData olu�tur
    CivData = NewObject<UCivilizationData>(this);

    // Temel civ verilerini y�kle
    CivData->BaseInfo = SelectedCiv;

    // �imdilik renk testleri
    CivData->CivColor = FLinearColor::Red;
    CivData->CivSecondaryColor = FLinearColor::Black;

    UE_LOG(LogTemp, Warning, TEXT("CivManager Initialized: %s"),
        *SelectedCiv.Name);
}



