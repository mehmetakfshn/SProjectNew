// Copyright Epic Games, Inc. All Rights Reserved.

#include "SProjectNew.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, SProjectNew, "SProjectNew" );

DEFINE_LOG_CATEGORY(LogSProjectNew)
 