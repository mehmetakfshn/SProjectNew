// Copyright Epic Games, Inc. All Rights Reserved.

#include "SProjectNewGameMode.h"

ASProjectNewGameMode::ASProjectNewGameMode()
{
	// stub
}