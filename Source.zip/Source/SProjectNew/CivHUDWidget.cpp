#include "CivHUDWidget.h"
#include "Components/Button.h"
#include "Components/TextBlock.h"     // YEN�
#include "CivPlayerController.h"      // Kendi PlayerController'�m�z
#include "CivGameState.h"             // YEN�: Tur say�s�n� buradan alaca��z


void UCivHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Butonun var oldu�undan ve Blueprint'te do�ru isimlendirildi�inden emin ol
	if (NextTurnButton)
	{
		// Butonun OnClicked (T�kland���nda) olay�na,
		// bizim OnNextTurnClicked fonksiyonumuzu ba�la (ekle).
		NextTurnButton->OnClicked.AddDynamic(this, &UCivHUDWidget::OnNextTurnClicked);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("CivHUDWidget: 'NextTurnButton' adli Buton Blueprint'te bulunamadi!"));
	}
}

void UCivHUDWidget::OnNextTurnClicked()
{
	// Bu UI Widget'�n�n sahibi olan PlayerController'� al
	ACivPlayerController* PC = Cast<ACivPlayerController>(GetOwningPlayer());
	if (PC)
	{
		// PlayerController'a "Turu bitirme iste�i g�nder" diyoruz
		// (Bu fonksiyonu bir sonraki ad�mda olu�turaca��z)
		PC->Server_RequestEndTurn();
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("OnNextTurnClicked: CivPlayerController bulunamadi!"));
	}
}

FText UCivHUDWidget::GetTurnText() const
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return FText::FromString(TEXT("Turn: ?"));
	}

	ACivGameState* CivGS = World->GetGameState<ACivGameState>();
	if (!CivGS)
	{
		return FText::FromString(TEXT("Turn: ?"));
	}

	int32 TurnNumber = CivGS->GetCurrentTurn();
	FText DateText = CivGS->GetCurrentDateText();

	FString FinalString = FString::Printf(TEXT("Turn: %d - %s"), TurnNumber, *DateText.ToString());
	return FText::FromString(FinalString);
}

