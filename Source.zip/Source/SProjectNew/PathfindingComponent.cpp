#include "PathfindingComponent.h"

UPathfindingComponent::UPathfindingComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

// YEN� FONKS�YON: BP'den gelen Dizi'yi C++'�n A* i�in ihtiya� duydu�u TMap'e d�n��t�r�r
TMap<FIntPoint, FHexTileData> UPathfindingComponent::ConvertArrayToMap(const TArray<FHexTileData>& GridDataArray)
{
	TMap<FIntPoint, FHexTileData> GridMap;
	for (const FHexTileData& TileData : GridDataArray)
	{
		GridMap.Add(TileData.Coordinates, TileData);
	}
	return GridMap;
}

// 1. A* Fonksiyonunun kendisi
bool UPathfindingComponent::FindPath(
	const TArray<FHexTileData>& GridDataArray,
	FIntPoint Start,
	FIntPoint End,
	TArray<FIntPoint>& OutPath
)
{
	// 1. ADIM: BP'den gelen Dizi'yi h�zl� arama i�in TMap'e d�n��t�r
	TMap<FIntPoint, FHexTileData> GridData = ConvertArrayToMap(GridDataArray);

	// 2. ADIM: A* algoritmas�n�n geri kalan�
	TArray<FPathNode*> OpenList;
	TArray<FPathNode*> ClosedList;

	FPathNode* StartNode = new FPathNode(Start, nullptr, 0, CalculateHeuristic(Start, End));
	OpenList.Add(StartNode);

	bool bPathFound = false;

	while (OpenList.Num() > 0)
	{
		// En d���k F-Cost'a sahip d���m� bul
		FPathNode* CurrentNode = OpenList[0];
		int32 CurrentIndex = 0;
		for (int32 i = 1; i < OpenList.Num(); i++)
		{
			if (OpenList[i]->FCost() < CurrentNode->FCost())
			{
				CurrentNode = OpenList[i];
				CurrentIndex = i;
			}
		}

		OpenList.RemoveAt(CurrentIndex);
		ClosedList.Add(CurrentNode);

		// Hedefe ula�t�k m�?
		if (CurrentNode->Coordinates == End)
		{
			OutPath = ReconstructPath(CurrentNode);
			bPathFound = true;
			break;
		}

		// Kom�ular� i�le
		for (FIntPoint NeighborCoords : GetNeighbors(CurrentNode->Coordinates))
		{
			const FHexTileData* NeighborTileData = GridData.Find(NeighborCoords);

			// Ge�erli bir karo mu? (Harita d���nda de�il VE y�r�nebilir)
			if (NeighborTileData == nullptr || NeighborTileData->Cost >= 9999)
			{
				continue; // Ge�ilemez (Da�/Su) veya harita d���
			}

			FPathNode TempNeighborNode(NeighborCoords);
			if (ClosedList.ContainsByPredicate([&](FPathNode* Node) { return *Node == TempNeighborNode; }))
			{
				continue; // Zaten i�lendi
			}

			int32 NewGCost = CurrentNode->GCost + NeighborTileData->Cost;

			FPathNode* NeighborNode = nullptr;
			for (FPathNode* Node : OpenList)
			{
				if (Node->Coordinates == NeighborCoords)
				{
					NeighborNode = Node;
					break;
				}
			}

			if (NeighborNode == nullptr)
			{
				NeighborNode = new FPathNode(NeighborCoords, CurrentNode, NewGCost, CalculateHeuristic(NeighborCoords, End));
				OpenList.Add(NeighborNode);
			}
			else if (NewGCost < NeighborNode->GCost)
			{
				NeighborNode->GCost = NewGCost;
				NeighborNode->Parent = CurrentNode;
			}
		}
	}

	// Belle�i temizle
	for (FPathNode* Node : OpenList) { delete Node; }
	for (FPathNode* Node : ClosedList) { delete Node; }

	return bPathFound;
}

// 3. Yolu Yeniden Olu�turma
TArray<FIntPoint> UPathfindingComponent::ReconstructPath(FPathNode* EndNode)
{
	TArray<FIntPoint> Path;
	FPathNode* Current = EndNode;
	while (Current != nullptr)
	{
		Path.Add(Current->Coordinates);
		Current = Current->Parent;
	}
	Algo::Reverse(Path);
	return Path;
}

// 4. Heuristic (Tahmini Maliyet) Hesaplama
int32 UPathfindingComponent::CalculateHeuristic(FIntPoint A, FIntPoint B)
{
	// "Odd-Q" (pointy-top) i�in Eksenel Mesafe
	FVector2D ACube((float)A.X, (float)A.Y - ((float)A.X + (A.X & 1)) / 2.0f);
	FVector2D BCube((float)B.X, (float)B.Y - ((float)B.X + (B.X & 1)) / 2.0f);
	float dx = FMath::Abs(ACube.X - BCube.X);
	float dy = FMath::Abs(ACube.Y - BCube.Y);
	float dz = FMath::Abs((-ACube.X - ACube.Y) - (-BCube.X - BCube.Y));
	return (int32)((dx + dy + dz) / 2.0f);
}

// 5. Kom�ular� Bulma
TArray<FIntPoint> UPathfindingComponent::GetNeighbors(FIntPoint Coords)
{
	// "Odd-Q" (dikey, sivri u�lu) d�zendeki 6 kom�unun y�n ofsetleri
	const bool bIsOddColumn = (Coords.X % 2 != 0);

	TArray<FIntPoint> Offsets;
	if (bIsOddColumn)
	{
		Offsets = {
			FIntPoint(0, -1), // N
			FIntPoint(1,  0), // NE
			FIntPoint(1,  1), // SE
			FIntPoint(0,  1), // S
			FIntPoint(-1,  1), // SW
			FIntPoint(-1,  0)  // NW
		};
	}
	else // �ift (Even) S�tun
	{
		Offsets = {
			FIntPoint(0, -1), // N
			FIntPoint(1, -1), // NE
			FIntPoint(1,  0), // SE
			FIntPoint(0,  1), // S
			FIntPoint(-1,  0), // SW
			FIntPoint(-1, -1)  // NW
		};
	}

	TArray<FIntPoint> Neighbors;
	for (const FIntPoint& Offset : Offsets)
	{
		Neighbors.Add(Coords + Offset);
	}
	return Neighbors;
}

// --- 6. YEN� HAR�TA MATEMAT�K ARA�LARI ---

FVector UPathfindingComponent::GridToWorld(FIntPoint GridCoord, float TileSize) const
{
	// N�HA� DO�RU "POINTY-TOP" (Sivri U�lu) KONUMLANDIRMA
	// Kaynak: Red Blob Games (Offset Coordinates, Odd-Q Vertical Layout)

	const float q = (float)GridCoord.X; // col
	const float r = (float)GridCoord.Y; // row
	const bool bIsOddColumn = (GridCoord.X % 2 != 0);

	// HexWidth = sqrt(3) * TileSize
	// HexHeight = 2.0 * TileSize
	const float HexWidth = FMath::Sqrt(3.0f) * TileSize;
	const float HexHeight = 2.0f * TileSize;

	// X Konumu: Her s�tun, geni�li�in 3/4'� kadar aral�kl�d�r.
	const float X = q * (HexWidth * 0.75f);

	// Y Konumu: Her sat�r, tam y�kseklik kadar aral�kl�d�r.
	float Y = r * HexHeight;
	if (bIsOddColumn)
	{
		// Tek s�tunlar yar�m y�kseklik kadar a�a�� kayar
		Y += HexHeight * 0.5f;
	}

	const float Z = 0.0f;
	return FVector(X, Y, Z);
}


FIntPoint UPathfindingComponent::WorldToGrid(const FVector& WorldLocation, float TileSize) const
{
	// N�HA� DO�RU "POINTY-TOP" (Sivri U�lu) TIKLAMA
	// Kaynak: Red Blob Games (Pixel to Hex, Axial Coordinates)

	const float q_axial_frac = ((FMath::Sqrt(3.0f) / 3.0f) * WorldLocation.X - (1.0f / 3.0f) * WorldLocation.Y) / TileSize;
	const float r_axial_frac = ((2.0f / 3.0f) * WorldLocation.Y) / TileSize;

	// Eksenel -> K�p
	FVector3f CubeFrac = FVector3f(q_axial_frac, -q_axial_frac - r_axial_frac, r_axial_frac);

	// Yuvarla
	int32 RoundX = FMath::RoundToInt(CubeFrac.X);
	int32 RoundY = FMath::RoundToInt(CubeFrac.Y);
	int32 RoundZ = FMath::RoundToInt(CubeFrac.Z);

	// D�zelt
	FVector3f CubeDiff = FVector3f(FMath::Abs((float)RoundX - CubeFrac.X), FMath::Abs((float)RoundY - CubeFrac.Y), FMath::Abs((float)RoundZ - CubeFrac.Z));

	if (CubeDiff.X > CubeDiff.Y && CubeDiff.X > CubeDiff.Z)
	{
		RoundX = -RoundY - RoundZ;
	}
	else if (CubeDiff.Y > CubeDiff.Z)
	{
		RoundY = -RoundX - RoundZ;
	}
	else
	{
		RoundZ = -RoundX - RoundY;
	}

	// K�p -> "odd-q" (pointy-top)
	const int32 FinalCol = RoundX;
	const int32 FinalRow = RoundZ + (RoundX + (RoundX & 1)) / 2;

	return FIntPoint(FinalCol, FinalRow);
}

FIntPoint UPathfindingComponent::WorldToGrid_Custom(const FVector& LocalPos, float TileSize) const
{
	// Senin Blueprint de�erlerine g�re:
	const float HexWidth = TileSize * FMath::Sqrt(3.0f);   // ? 173.205
	const float HexHeight = TileSize * 1.5f;                // = 150.0

	// Column = X hizas�
	int32 Col = FMath::RoundToInt(LocalPos.X / HexWidth);

	// Even / Odd column offset
	bool bOdd = (Col % 2 != 0);

	// Row = Y hizas� (Z tamamen �nemsiz)
	float AdjustedY = LocalPos.Y;
	const float OddOffset = HexHeight * 0.5f;  // = 75 -> Blueprint ile birebir uyumlu

	if (bOdd)
	{
		AdjustedY -= OddOffset;
	}

	int32 Row = FMath::RoundToInt(AdjustedY / HexHeight);

	return FIntPoint(Col, Row);
}

