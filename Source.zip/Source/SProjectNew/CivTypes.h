#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "CivTypes.generated.h"

/**
 * Bu s�n�f sadece o Struct'� bar�nd�rmak i�in var, .cpp dosyas�na ihtiyac�m�z yok.
 */
UCLASS()
class SPROJECTNEW_API UCivTypes : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
};